package com.example.myapplication

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Pobranie referencji do widoków
        val etProwizja: EditText = findViewById(R.id.etProwizja)
        val switchOprocentowanie: Switch = findViewById(R.id.switchOprocentowanie)
        val seekBarKwota: SeekBar = findViewById(R.id.seekBarKwota)
        val seekBarDni: SeekBar = findViewById(R.id.seekBarDni)
        val tvKwota: TextView = findViewById(R.id.tvKwota)
        val tvDni: TextView = findViewById(R.id.tvDni)
        val tvWynik: TextView = findViewById(R.id.tvWynik)
        val btnOblicz: Button = findViewById(R.id.btnOblicz)

        // Aktualizacja tekstu podczas zmiany SeekBar dla kwoty
        seekBarKwota.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvKwota.text = "$progress PLN"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Aktualizacja tekstu podczas zmiany SeekBar dla liczby dni
        seekBarDni.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvDni.text = "$progress dni"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Obsługa kliknięcia przycisku "Oblicz"
        btnOblicz.setOnClickListener {
            val prowizja = etProwizja.text.toString().toDoubleOrNull() ?: 0.0
            val kwota = seekBarKwota.progress
            val dni = seekBarDni.progress

            // Sprawdzenie, czy oprocentowanie jest włączone
            val oprocentowanie = if (switchOprocentowanie.isChecked) 0.05 else 0.02

            // Obliczenie raty kredytu
            val rata = (kwota + (kwota * oprocentowanie) + prowizja) / dni

            // Wyświetlenie wyniku
            tvWynik.text = "Wynik: %.2f PLN".format(rata)
        }
    }
}
